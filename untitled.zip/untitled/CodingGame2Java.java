import java.util.*;
import java.io.*;
import java.math.*;
import java.util.ArrayList;

class GameMap {
    private static final int WATER = 0;
    private static final int ISLAND = 1;
    private static final int VISITED_BY_ME = 2;

    public int width;
    public int height;

    private final int[][] gameMap;

    public GameMap(int width, int height, ArrayList<String> stringMap) {
        this.width = width;
        this.height = height;

        this.gameMap = new int[width][height];
        for (int i = 0; i < stringMap.size(); i++) {
            for (int j = 0; j < stringMap.get(i).length(); j++) {
                gameMap[i][j] = stringMap.get(i).charAt(j) == 'x' ? ISLAND : WATER;
            }
        }
    }

    public Coordinate getNextEmptyCell() {
        while (true) {
            Random r = new Random();
            Coordinate coordinate = new Coordinate(r.nextInt(width), r.nextInt(height));
            if (isCoordinateSafeToMove(coordinate)) {
                return coordinate;
            }
        }
    }

    public boolean isCellOnMap(Coordinate coordinate) {
        return coordinate.getX() >= 0 && coordinate.getX() < width && coordinate.getY() >= 0 && coordinate.getY() < height;
    }

    public boolean isCoordinateSafeToMove(Coordinate coordinate) {
        return isCellOnMap(coordinate) && gameMap[coordinate.getY()][coordinate.getX()] == WATER;
    }

    public void setMyPathTrace(Coordinate coordinate) {
        gameMap[coordinate.getY()][coordinate.getX()] = VISITED_BY_ME;
    }

    public void resetMyPathTraces() {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                gameMap[i][j] = gameMap[i][j] == VISITED_BY_ME ? WATER : gameMap[i][j];
            }
        }
    }

    public String getBestDirection(Coordinate position) {
        Coordinate north = new Coordinate(position.getX(), position.getY() - 1);
        Coordinate south = new Coordinate(position.getX(), position.getY() + 1);
        Coordinate east = new Coordinate(position.getX() + 1, position.getY());
        Coordinate west = new Coordinate(position.getX() - 1, position.getY());

        int northCells = backtrack(gameMap, north, new ArrayList<>());
        int southCells = backtrack(gameMap, south, new ArrayList<>());
        int eastCells = backtrack(gameMap, east, new ArrayList<>());
        int westCells = backtrack(gameMap, west, new ArrayList<>());


        int maxCells = Math.max(northCells, Math.max(southCells, Math.max(eastCells, westCells)));

        if (maxCells == 0) {
            return "-";
        }
        if (northCells == maxCells) {
            return "N";
        }
        if (southCells == maxCells) {
            return "S";
        }
        if (eastCells == maxCells) {
            return "E";
        }
        return "W";
    }

    public int backtrack(int[][] gameMap, Coordinate pos, ArrayList<Coordinate> visited) {
        if (!isCellOnMap(pos) || !isCoordinateSafeToMove(pos) || arrayContainsPosition(visited, pos)) {
            return 0;
        }
        setMyPathTrace(pos);
        visited.add(pos);

        Coordinate north = new Coordinate(pos.getX(), pos.getY() - 1);
        Coordinate south = new Coordinate(pos.getX(), pos.getY() + 1);
        Coordinate east = new Coordinate(pos.getX() + 1, pos.getY());
        Coordinate west = new Coordinate(pos.getX() - 1, pos.getY());

        int northCells = backtrack(gameMap, north, visited);
        int southCells = backtrack(gameMap, south, visited);
        int eastCells = backtrack(gameMap, east, visited);
        int westCells = backtrack(gameMap, west, visited);

        gameMap[pos.getY()][pos.getX()] = WATER;

        return Math.max(northCells, Math.max(southCells, Math.max(eastCells, westCells))) + 1;
    }

    private boolean arrayContainsPosition(ArrayList<Coordinate> visited, Coordinate pos) {
        for (int i = 0; i < visited.size(); i++) {
            if (visited.get(i).equals(pos)) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<Coordinate> getEnemyPossiblePosition(String moves) {
        ArrayList<Coordinate> coordinates = new ArrayList<>();
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                Coordinate endPos = getEnemyCurrentPosition(new Coordinate(j, i), moves);
                if (endPos != null) {
                    coordinates.add(endPos);
                }
            }
        }
        return coordinates;
    }

    private Coordinate getEnemyCurrentPosition(Coordinate pos, String moves) {

        if (!isCellOnMap(pos) || gameMap[pos.getY()][pos.getX()] == GameMap.ISLAND) {
            return null;
        }

        for (int i = 0; i < moves.length(); i++) {
            if (moves.charAt(i) == 'n') {
                pos = new Coordinate(pos.getX(), pos.getY() - 1);
            }
            if (moves.charAt(i) == 's') {
                pos = new Coordinate(pos.getX(), pos.getY() + 1);
            }
            if (moves.charAt(i) == 'e') {
                pos = new Coordinate(pos.getX() + 1, pos.getY());
            }
            if (moves.charAt(i) == 'w') {
                pos = new Coordinate(pos.getX() - 1, pos.getY());
            }
            if (!isCellOnMap(pos) || gameMap[pos.getY()][pos.getX()] == GameMap.ISLAND) {
                return null;
            }
        }
        return pos;
    }
}

class Coordinate {
    public int x;
    public int y;

    public Coordinate(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int calculateDistance(Coordinate coordinate) {
        return Math.abs(x - coordinate.x) + Math.abs(y - coordinate.y);
    }

    @Override
    public String toString() {
        return "x=" + x + " y=" + y;
    }

    @Override
    public boolean equals(Object obj) {
        Coordinate coordinate = (Coordinate) obj;
        return x == coordinate.getX() && y == coordinate.getY();
    }
}

class Submarine {
    private Coordinate position;
    private int life;
    private int torpedoCooldown;
    private int sonarCooldown;
    private int silenceCooldown;
    private int mineCooldown;
    private GameMap gameMap;
    private String moves = "";
    private Submarine enemy;

    public void update(Coordinate position, int life, int torpedoCooldown, int sonarCooldown, int silenceCooldown, int mineCooldown) {
        this.position = position;
        this.life = life;
        this.torpedoCooldown = torpedoCooldown;
        this.sonarCooldown = sonarCooldown;
        this.silenceCooldown = silenceCooldown;
        this.mineCooldown = mineCooldown;

        gameMap.setMyPathTrace(position);
    }

    public void setEnemy(Submarine enemy) {
        this.enemy = enemy;
    }

    public String getMoves() {
        return moves;
    }

    public void updateOrders(String ordersString) {

        if (ordersString.equals("NA")) {
            return;
        }

        String[] orders = ordersString.split("\\|");

        System.err.println("Enemy orders:");
        for (String order : orders) {
            order = order.trim().toLowerCase();
            if (order.startsWith("move")) {
                String dir = order.split(" ")[1].trim();
                moves += dir;
            }
        }
    }

    public void setMap(GameMap gameMap) {
        this.gameMap = gameMap;
    }

    public void play() {
        move();
        shoot();
        System.out.println();
    }

    private void move() {

        String direction = gameMap.getBestDirection(position);

        if (!direction.equals("-")) {
            moveTo(direction);
            return;
        } else {
            surface();
        }
    }

    private void shoot() {
        if (torpedoCooldown == 0) {

            ArrayList<Coordinate> enemyPossiblePositions = gameMap.getEnemyPossiblePosition(enemy.getMoves());

            System.err.println("Enemy possible positions: ");
            for (Coordinate pos : enemyPossiblePositions) {
                System.err.println(pos);
                if (position.calculateDistance(pos) <= 4) {
                    shootAt(pos);
                    break;
                }
            }
        }
    }

    private boolean tryToSilence() {
        if (silenceCooldown > 0) {
            return false;
        }

        for (int i = 2; i <= 4; i++) {
            Coordinate north = new Coordinate(position.getX(), position.getY() - i);
            Coordinate south = new Coordinate(position.getX(), position.getY() + i);
            Coordinate east = new Coordinate(position.getX() + i, position.getY());
            Coordinate west = new Coordinate(position.getX() - i, position.getY());

            if (gameMap.isCoordinateSafeToMove(north)) {
                silenceTo("N", i);
                return true;
            } else if (gameMap.isCoordinateSafeToMove(south)) {
                silenceTo("S", i);
                return true;
            } else if (gameMap.isCoordinateSafeToMove(east)) {
                silenceTo("E", i);
                return true;
            } else if (gameMap.isCoordinateSafeToMove(west)) {
                silenceTo("W", i);
                return true;
            }
        }
        return false;
    }

    private void moveTo(String direction) {
        System.out.print("MOVE " + direction);
        charge();
    }

    private void silenceTo(String direction, int distance) {
        System.out.print("SILENCE " + direction + " " + distance);
    }

    private void charge() {
        System.out.print(" TORPEDO");
        // if (silenceCooldown > 0) {
        //     System.out.print(" SILENCE");
        // } else {
        //     System.out.print(" TORPEDO");
        // }
    }

    private void shootAt(Coordinate coordinate) {
        System.out.print(" | TORPEDO " + coordinate.getX() + " " + coordinate.getY());
    }

    private void surface() {
        System.out.print("SURFACE");
        gameMap.resetMyPathTraces();
    }
}

/**
 * Auto-generated code below aims at helping you parse
 * the standard input according to the problem statement.
 **/
class Player {

    GameMap gameMap;
    Submarine me = new Submarine();
    Submarine enemy = new Submarine();

    public static void main(String[] args) {
        new Player().run();
    }

    private void run() {

        me.setEnemy(enemy);
        enemy.setEnemy(me);

        Scanner in = new Scanner(System.in);
        int width = in.nextInt();
        int height = in.nextInt();
        int myId = in.nextInt();
        if (in.hasNextLine()) {
            in.nextLine();
        }

        ArrayList<String> gameMapLines = new ArrayList<>();
        for (int i = 0; i < height; i++) {
            gameMapLines.add(in.nextLine());
        }

        gameMap = new GameMap(width, height, gameMapLines);
        me.setMap(gameMap);
        enemy.setMap(gameMap);

        // Write an action using System.out.println()
        // To debug: System.err.println("Debug messages...")

        Coordinate initialPosition = gameMap.getNextEmptyCell();


        System.out.println(initialPosition.getX() + " " + initialPosition.getY());

        // game loop
        while (true) {
            int x = in.nextInt();
            int y = in.nextInt();
            int myLife = in.nextInt();
            int oppLife = in.nextInt();
            int torpedoCooldown = in.nextInt();
            int sonarCooldown = in.nextInt();
            int silenceCooldown = in.nextInt();
            int mineCooldown = in.nextInt();
            String sonarResult = in.next();
            if (in.hasNextLine()) {
                in.nextLine();
            }
            String opponentOrders = in.nextLine();

            enemy.updateOrders(opponentOrders);

            me.update(
                    new Coordinate(x, y), myLife, torpedoCooldown, sonarCooldown, silenceCooldown, mineCooldown
            );
            // Write an action using System.out.println()
            // To debug: System.err.println("Debug messages...");

            me.play();
        }
    }
}