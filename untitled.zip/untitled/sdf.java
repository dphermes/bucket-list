
/**
 * Auto-generated code below aims at helping you parse
 * the standard input according to the problem statement.
 **/
class Player {
    map: Map;
    me: Submarine = new Submarine();
    ennemy: Submarine = new Submarine();

    public static main(args: string[]): void {
        new Player().run();
    }

    private run(): void {
        this.me.setEnnemy(this.ennemy);
        this.ennemy.setEnnemy(this.me);

        const in = readline.createInterface({
                input: process.stdin,
                output: process.stdout,
                terminal: false,
        })

        let width: number, height: number, myId: number;

        in.on('line', (line: string) => {
            const tokens = line.split(' ');

            if (tokens.length === 2) {
                width = parseInt(tokens[0]);
                height = parseInt(tokens[1]);
                myId = parseInt(tokens[2]);
            } else {
                const mapLines: string[] = []

                for (let i = 0; i < height; i++) {
                    mapLines.push(line);
                    if (i !== height - 1) {
                        line = in.readline();
                    }
                }

                this.map = new Map(width, height, mapLines);
                this.me.setMap(this.map);
                this.ennemy.setMap(this.map);

                const initialPosition: Point = this.map.getEmptyCell();

                console.log(`${initialPosition.getX()} ${initialPosition.getY()}`)

                in.on('line', (line: string) => {
                    const [x, y, myLife, oppLife, torpedoCooldown, sonarCooldown, silenceCooldown, mineCooldown, sonarResult] = line.split(' ');
                    const opponentOrders: string = in.readline();

                    this.ennemy.updateOrders(opponentOrders);

                    this.me.update(
                            new Point(parseInt(x), parseInt(y)), parseInt(myLife), parseInt(torpedoCooldown),
                            parseInt(sonarCooldown), parseInt(silenceCooldown), parseInt(mineCooldown)
                    );

                    this.me.play();
                })
            }
        })
    }
}