class Map {
    private static EMPTY = 0;
    private static ISLAND = 1;
    private static VISITED_BY_ME = 2;

    public width: number;
    public height: number;

    private map: number[][];

    constructor(width: number, height: number, stringMap: string[]) {
        this.width = width;
        this.height = height;

        this.map = new Array(height).fill(null).map(() => new Array(width).fill(0));

        for (let i = 0; i < stringMap.length; i++) {
            for (let j = 0; j < stringMap[i].length; j++) {
                this.map[i][j] = stringMap[i].charAt(j) === 'x' ? Map.ISLAND : Map.EMPTY;
            }
        }
    }

    public getEmptyCell(): Point {
        while (true) {
            const point = new Point(Math.floor(Math.random() * this.width), Math.floor(Math.random() * this.height));
            if (this.isSafeToMove(point)) {
                return point;
            }
        }
    }

    public isOnTheMap(point: Point): boolean {
        return point.x >= 0 && point.x < this.width && point.y >= 0 && point.y < this.height;
    }

    public isSafeToMove(point: Point): boolean {
        return this.isOnTheMap(point) && this.map[point.y][point.x] === Map.EMPTY;
    }

    public setVisitedCell(point: Point): void {
        this.map[point.y][point.x] = Map.VISITED_BY_ME;
    }

    public resetVisitedCells(): void {
        for (let i = 0; i < this.height; i++) {
            for (let j = 0; j < this.width; j++) {
                this.map[i][j] = this.map[i][j] === Map.VISITED_BY_ME ? Map.EMPTY : this.map[i][j];
            }
        }
    }

    public getBestDirection(position: Point): string {
        const north = new Point(position.x, position.y - 1);
        const south = new Point(position.x, position.y + 1);
        const east = new Point(position.x + 1, position.y);
        const west = new Point(position.x - 1, position.y);

        const northCells = this.backtrack(this.map, north, []);
        const southCells = this.backtrack(this.map, south, []);
        const eastCells = this.backtrack(this.map, east, []);
        const westCells = this.backtrack(this.map, west, []);

        const maxCells = Math.max(northCells, Math.max(southCells, Math.max(eastCells, westCells)));

        if (maxCells === 0) {
            return '-';
        }

        if (northCells === maxCells) {
            return 'N';
        }
        if (southCells === maxCells) {
            return 'S';
        }
        if (eastCells === maxCells) {
            return 'E';
        }
        return 'W';
    }

    backtrack(map: number[][], pos: Point, visited: Point[]): number {
        if (!this.isOnTheMap(pos) || !this.isSafeToMove(pos) || this.arrayContainsPosition(visited, pos)) {
            return 0;
        }
        this.setVisitedCell(pos);
        visited.push(pos);

        const north = new Point(pos.getX(), pos.getY() - 1);
        const south = new Point(pos.getX(), pos.getY() + 1);
        const east = new Point(pos.getX() + 1, pos.getY());
        const west = new Point(pos.getX() - 1, pos.getY());

        const northCells = this.backtrack(map, north, visited);
        const southCells = this.backtrack(map, south, visited);
        const eastCells = this.backtrack(map, east, visited);
        const westCells = this.backtrack(map, west, visited);

        map[pos.getY()][pos.getX()] = Map.EMPTY;

        return Math.max(northCells, Math.max(southCells, Math.max(eastCells, westCells))) + 1;
    }

    arrayContainsPosition(visited: Point[], pos: Point): boolean {
        for (let i = 0; i < visited.length; i++) {
            if (visited[i].equals(pos)) {
                return true;
            }
        }
        return false;
    }

    getPossiblePositionBasedOnMoves(moves: string): Point[] {
        const points: Point[] = [];
        for(let i = 0; i < this.height; i++) {
            for(let j = 0; j < this.width; j++) {
                const endPos = this.getCurrentPositionBasedOnInitialPositionAndMoves(new Point(j, i), moves);
                if (endPos !== null) {
                    points.push(endPos);
                }
            }
        }
        return points;
    }

    private getCurrentPositionBasedOnInitialPositionAndMoves(pos: Point, moves: string): Point | null {
        if (!this.isOnTheMap(pos) || this.map[pos.getY()][pos.getX()] === Map.ISLAND) {
            return null;
        }

        for (let i = 0; i < moves.length; i++) {
            if (moves.charAt(i) === 'n') {
                pos = new Point(pos.getX(), pos.getY() - 1);
            }
            if (moves.charAt(i) === 's') {
                pos = new Point(pos.getX(), pos.getY() + 1);
            }
            if (moves.charAt(i) === 'e') {
                pos = new Point(pos.getX() + 1, pos.getY());
            }
            if (moves.charAt(i) === 'w') {
                pos = new Point(pos.getX() - 1, pos.getY());
            }
            if (!this.isOnTheMap(pos) || this.map[pos.getY()][pos.getX()] === Map.ISLAND) {
                return null;
            }
        }

        return pos;
    }
}

class Point {
    public x: number;
    public y: number;

    constructor(x: number, y: number) {
        this.x = x;
        this.y = y;
    }

    public getX(): number {
        return this.x;
    }

    public setX(x: number): void {
        this.x = x;
    }

    public getY(): number {
        return this.y;
    }

    public setY(y: number): void {
        this.y = y;
    }

    public dist(point: Point): number {
        return Math.abs(this.x - point.x) + Math.abs(this.y - point.y);
    }

    public toString(): string {
        return `x=${this.x} y=${this.y}`;
    }

    public equals(obj: any): boolean {
        const point: Point = obj as Point;
        return this.x === point.getX() && this.y === point.getY();
    }
}

class Submarine {
    private position: Point;
    private life: number;
    private torpedoCooldown: number;
    private sonarCooldown: number;
    private silenceCooldown: number;
    private mineCooldown: number;
    private map: Map;
    private moves: string = "";
    private ennemy?: Submarine;

    public update(position: Point, life: number, torpedoCooldown: number, sonarCooldown: number, silenceCooldown: number, mineCooldown: number): void {
        this.position = position;
        this.life = life;
        this.torpedoCooldown = torpedoCooldown;
        this.sonarCooldown = sonarCooldown;
        this.silenceCooldown = silenceCooldown;
        this.mineCooldown = mineCooldown;

        this.map.setVisitedCell(position);
    }

    public setEnnemy(ennemy: Submarine): void {
        this.ennemy = ennemy;
    }

    public getMoves(): string {
        return this.moves;
    }

    public updateOrders(ordersString: string): void {

        if (ordersString === "NA") {
            return;
        }

        const orders = ordersString.split("\\|");

        console.log("Ennemy orders:");
        for (const order of orders) {
            const trimmedOrder = order.trim().toLowerCase();
            if (trimmedOrder.startsWith("move")) {
                const dir = trimmedOrder.split(" ")[1].trim();
                this.moves += dir;
            }
        }
    }

    public setMap(map: Map): void {
        this.map = map;
    }

    public play(): void {
        this.move();
        this.shoot();
        console.log();
    }


    private move(): void {
        const direction: string = this.map.getBestDirection(this.position);

        if (direction !== '-') {
            this.moveTo(direction);
            return;
        } else {
            this.surface();
        }
    }

    private shoot(): void {
        if (this.torpedoCooldown === 0) {
            const ennemyPossiblePositions: Array<Point> = this.map.getPossiblePositionBasedOnMoves(this.ennemy.getMoves());

            console.log('Ennemy possible positions:');
            for (const pos of ennemyPossiblePositions) {
                console.log(pos);
                if (this.position.dist(pos) <= 4) {
                    this.shootAt(pos);
                    break;
                }
            }
        }
    }

    private tryToSilence(): boolean {
        if (this.silenceCooldown > 0) {
            return false;
        }

        for (let i = 2; i <= 4; i++) {
            const north: Point = new Point(this.position.getX(), this.position.getY() - i);
            const south: Point = new Point(this.position.getX(), this.position.getY() + i);
            const east: Point = new Point(this.position.getX() + i, this.position.getY());
            const west: Point = new Point(this.position.getX() - i, this.position.getY());

            if (this.map.isSafeToMove(north)) {
                this.silenceTo('N', i);
                return true;
            } else if (this.map.isSafeToMove(south)) {
                this.silenceTo('S', i);
                return true;
            } else if (this.map.isSafeToMove(east)) {
                this.silenceTo('E', i);
                return true;
            } else if (this.map.isSafeToMove(west)) {
                this.silenceTo('W', i);
                return true;
            }
        }
        return false;
    }

    private moveTo(direction: string): void {
        console.log(`MOVE ${direction}`);
        this.charge();
    }

    private silenceTo(direction: string, distance: number): void {
        console.log(`SILENCE ${direction} ${distance}`);
    }

    private charge(): void {
        console.log(" TORPEDO");
        // if (silenceCooldown > 0) {
        //     System.out.print(" SILENCE");
        // } else {
        //     System.out.print(" TORPEDO");
        // }
    }

    private shootAt(point: Point): void {
        console.log(` | TORPEDO ${point.getX()} ${point.getY()}`);
    }

    private surface(): void {
        console.log("SURFACE");
        map.resetVisitedCells();
    }
}

/**
 * Auto-generated code below aims at helping you parse
 * the standard input according to the problem statement.
 **/
class Player {
    map: Map;
    me: Submarine = new Submarine();
    ennemy: Submarine = new Submarine();

    public static main(args: string[]): void {
        new Player().run();
    }

    private run(): void {
        this.me.setEnnemy(this.ennemy);
        this.ennemy.setEnnemy(this.me);

        const in = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
            terminal: false,
        });

        let width: number, height: number, myId: number;

    in.on('line', (line: string) => {
            const tokens = line.split(' ');

            if (tokens.length === 2) {
                width = parseInt(tokens[0]);
                height = parseInt(tokens[1]);
                myId = parseInt(tokens[2]);
            } else {
                const mapLines: string[] = [];

                for (let i = 0; i < height; i++) {
                    mapLines.push(line);
                    if (i !== height - 1) {
                        line = in.readline();
                    }
                }

                this.map = new Map(width, height, mapLines);
                this.me.setMap(this.map);
                this.ennemy.setMap(this.map);

                const initialPosition: Point = this.map.getEmptyCell();

                console.log(`${initialPosition.getX()} ${initialPosition.getY()}`);

            in.on('line', (line: string) => {
                    const [x, y, myLife, oppLife, torpedoCooldown, sonarCooldown, silenceCooldown, mineCooldown, sonarResult] = line.split(' ');
                    const opponentOrders: string = in.readline();

                    this.ennemy.updateOrders(opponentOrders);

                    this.me.update(
                        new Point(parseInt(x), parseInt(y)), parseInt(myLife), parseInt(torpedoCooldown),
                        parseInt(sonarCooldown), parseInt(silenceCooldown), parseInt(mineCooldown)
                    );

                    this.me.play();
                });
            }
        });
    }
}