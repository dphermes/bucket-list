import java.util.*;
import java.io.*;
import java.math.*;
import java.util.ArrayList;

class Map {
    private static final int EMPTY = 0;
    private static final int ISLAND = 1;
    private static final int VISITED_BY_ME = 2;
    private static final int VISITED_BY_ENNEMY = 3;

    public int width;
    public int height;

    private final int[][] map;

    public Map(int width, int height, ArrayList<String> stringMap) {
        this.width = width;
        this.height = height;

        this.map = new int[width][height];
        for(int i = 0; i < stringMap.size(); i++) {
            for(int j = 0; j < stringMap.get(i).length(); j++) {
                map[i][j] = stringMap.get(i).charAt(j) == 'x' ? ISLAND : EMPTY;
            }
        }
    }

    public Point getEmptyCell() {
        while (true) {
            Random r = new Random();
            Point point = new Point(r.nextInt(width), r.nextInt(height));
            if (isSafeToMove(point)) {
                return point;
            }
        }
    }

    public boolean isOnTheMap(Point point) {
        return point.getX() >= 0 && point.getX() < width && point.getY() >= 0 && point.getY() < height;
    }

    public boolean isSafeToMove(Point point) {
        return isOnTheMap(point) && map[point.getY()][point.getX()] == EMPTY;
    }

    public void setVisitedCell(Point point) {
        map[point.getY()][point.getX()] = VISITED_BY_ME;
    }

    public void resetVisitedCells() {
        for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                map[i][j] = map[i][j] == VISITED_BY_ENNEMY ? EMPTY : map[i][j];
            }
        }
    }

    public void resetEnnemyVisitedCells() {
        for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                map[i][j] = map[i][j] == VISITED_BY_ME ? EMPTY : map[i][j];
            }
        }
    }

    public String getBestDirection(Point position) {
        Point north = new Point(position.getX(), position.getY() - 1);
        Point south = new Point(position.getX(), position.getY() + 1);
        Point east = new Point(position.getX() + 1, position.getY());
        Point west = new Point(position.getX() - 1, position.getY());

        int northCells = backtrack(map, north, new ArrayList<>());
        int southCells = backtrack(map, south, new ArrayList<>());
        int eastCells = backtrack(map, east, new ArrayList<>());
        int westCells = backtrack(map, west, new ArrayList<>());


        int maxCells = Math.max(northCells, Math.max(southCells, Math.max(eastCells, westCells)));

        if (maxCells == 0) {
            return "-";
        }

        if (northCells == maxCells) {
            return "N";
        }
        if (southCells == maxCells) {
            return "S";
        }
        if (eastCells == maxCells) {
            return "E";
        }
        return "W";
    }

    public int backtrack(int[][] map, Point pos, ArrayList<Point> visited) {
        if (!isOnTheMap(pos) || !isSafeToMove(pos) || arrayContainsPosition(visited, pos)) {
            return 0;
        }
        setVisitedCell(pos);
        visited.add(pos);

        Point north = new Point(pos.getX(), pos.getY() - 1);
        Point south = new Point(pos.getX(), pos.getY() + 1);
        Point east = new Point(pos.getX() + 1, pos.getY());
        Point west = new Point(pos.getX() - 1, pos.getY());

        int northCells = backtrack(map, north, visited);
        int southCells = backtrack(map, south, visited);
        int eastCells = backtrack(map, east, visited);
        int westCells = backtrack(map, west, visited);

        map[pos.getY()][pos.getX()] = EMPTY;

        return Math.max(northCells, Math.max(southCells, Math.max(eastCells, westCells))) + 1;
    }

    private boolean arrayContainsPosition(ArrayList<Point> visited, Point pos) {
        for (int i = 0; i < visited.size(); i++) {
            if (visited.get(i).equals(pos)) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<Point> getPossiblePositionBasedOnMoves(String moves) {
        ArrayList<Point> points = new ArrayList<>();
        for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                Point endPos = getCurrentPositionBasedOnInitialPositionAndMoves(new Point(j, i), moves);
                if (endPos != null) {
                    points.add(endPos);
                }
            }
        }
        return points;
    }

    private Point getCurrentPositionBasedOnInitialPositionAndMoves(Point pos, String moves) {

        if (!isOnTheMap(pos) || map[pos.getY()][pos.getX()] == Map.ISLAND) {
            return null;
        }

        for(int i = 0; i < moves.length(); i++) {
            if (moves.charAt(i) == 'n') {
                pos = new Point(pos.getX(), pos.getY() - 1);
            }
            if (moves.charAt(i) == 's') {
                pos = new Point(pos.getX(), pos.getY() + 1);
            }
            if (moves.charAt(i) == 'e') {
                pos = new Point(pos.getX() + 1, pos.getY());
            }
            if (moves.charAt(i) == 'w') {
                pos = new Point(pos.getX() - 1, pos.getY());
            }
            if (!isOnTheMap(pos) || map[pos.getY()][pos.getX()] == Map.ISLAND) {
                return null;
            }
        }
        return pos;
    }
}

class Point {
    public int x;
    public int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int dist(Point point) {
        return Math.abs(x - point.x) + Math.abs(y - point.y);
    }

    @Override
    public String toString() {
        return "x=" + x + " y=" + y;
    }

    @Override
    public boolean equals(Object obj) {
        Point point = (Point) obj;
        return x == point.getX() && y == point.getY();
    }
}

class Submarine {
    private Point position;
    private int life;
    private int torpedoCooldown;
    private int sonarCooldown;
    private int silenceCooldown;
    private int mineCooldown;
    private Map map;
    private String moves = "";
    private Submarine ennemy;

    public void update(Point position, int life, int torpedoCooldown, int sonarCooldown, int silenceCooldown, int mineCooldown) {
        this.position = position;
        this.life = life;
        this.torpedoCooldown = torpedoCooldown;
        this.sonarCooldown = sonarCooldown;
        this.silenceCooldown = silenceCooldown;
        this.mineCooldown = mineCooldown;

        map.setVisitedCell(position);
    }

    public void setEnnemy(Submarine ennemy) {
        this.ennemy = ennemy;
    }

    public String getMoves() {
        return moves;
    }

    public void updateOrders(String ordersString) {

        if (ordersString.equals("NA")) {
            return;
        }

        String[] orders = ordersString.split("\\|");

        System.err.println("Ennemy orders:");
        for (String order: orders) {
            order = order.trim().toLowerCase();
            if (order.startsWith("move")) {
                String dir = order.split(" ")[1].trim();
                moves += dir;
            } else if (order.startsWith("surface")) {
                map.resetEnnemyVisitedCells();
            }
        }
    }

    public void setMap(Map map) {
        this.map = map;
    }

    public void play() {
        move();
        shoot();
        System.out.println();
    }

    private void move() {

        String direction = map.getBestDirection(position);

        if (!direction.equals("-")) {
            moveTo(direction);
            return;
        } else {
            surface();
        }
    }

    private void shoot() {
        if (torpedoCooldown == 0) {

            ArrayList<Point> ennemyPossiblePositions = map.getPossiblePositionBasedOnMoves(ennemy.getMoves());

            System.err.println("Ennemy possible positions: ");
            for (Point pos: ennemyPossiblePositions) {
                System.err.println(pos);
                if (position.dist(pos) <= 4) {
                    shootAt(pos);
                    break;
                }
            }
        }
    }

    private boolean tryToSilence() {
        if (silenceCooldown > 0) {
            return false;
        }

        for (int i = 2; i <= 4; i++) {
            Point north = new Point(position.getX(), position.getY() - i);
            Point south = new Point(position.getX(), position.getY() + i);
            Point east = new Point(position.getX() + i, position.getY());
            Point west = new Point(position.getX() - i, position.getY());

            if (map.isSafeToMove(north)) {
                silenceTo("N", i);
                return true;
            } else if (map.isSafeToMove(south)) {
                silenceTo("S", i);
                return true;
            } else if (map.isSafeToMove(east)) {
                silenceTo("E", i);
                return true;
            } else if (map.isSafeToMove(west)) {
                silenceTo("W", i);
                return true;
            }
        }
        return false;
    }

    private void moveTo(String direction) {
        System.out.print("MOVE " + direction);
        charge();
    }

    private void silenceTo(String direction, int distance) {
        System.out.print("SILENCE " + direction + " " + distance);
    }

    private void charge() {
        System.out.print(" TORPEDO");
        // if (silenceCooldown > 0) {
        //     System.out.print(" SILENCE");
        // } else {
        //     System.out.print(" TORPEDO");
        // }
    }

    private void shootAt(Point point) {
        System.out.print(" | TORPEDO " + point.getX() + " " + point.getY());
    }

    private void surface() {
        System.out.print("SURFACE");
        map.resetVisitedCells();
    }
}

/**
 * Auto-generated code below aims at helping you parse
 * the standard input according to the problem statement.
 **/
class Player {

    Map map;
    Submarine me = new Submarine();
    Submarine ennemy = new Submarine();

    public static void main(String[] args) {
        new Player().run();
    }

    private void run() {

        me.setEnnemy(ennemy);
        ennemy.setEnnemy(me);

        Scanner in = new Scanner(System.in);
        int width = in.nextInt();
        int height = in.nextInt();
        int myId = in.nextInt();
        if (in.hasNextLine()) {
            in.nextLine();
        }

        ArrayList<String> mapLines = new ArrayList<>();
        for (int i = 0; i < height; i++) {
            mapLines.add(in.nextLine());
        }

        map = new Map(width, height, mapLines);
        me.setMap(map);
        ennemy.setMap(map);

        // Write an action using System.out.println()
        // To debug: System.err.println("Debug messages...")

        Point initialPosition = map.getEmptyCell();


        System.out.println(initialPosition.getX() + " " + initialPosition.getY());

        // game loop
        while (true) {
            int x = in.nextInt();
            int y = in.nextInt();
            int myLife = in.nextInt();
            int oppLife = in.nextInt();
            int torpedoCooldown = in.nextInt();
            int sonarCooldown = in.nextInt();
            int silenceCooldown = in.nextInt();
            int mineCooldown = in.nextInt();
            String sonarResult = in.next();
            if (in.hasNextLine()) {
                in.nextLine();
            }
            String opponentOrders = in.nextLine();

            ennemy.updateOrders(opponentOrders);

            me.update(
                    new Point(x, y), myLife, torpedoCooldown, sonarCooldown, silenceCooldown, mineCooldown
            );
            // Write an action using System.out.println()
            // To debug: System.err.println("Debug messages...");

            me.play();
        }
    }
}