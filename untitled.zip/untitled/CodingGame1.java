import java.util.*;
import java.io.*;
import java.math.*;
import java.util.ArrayList;

class Map {
    private static final int EMPTY = 0;
    private static final int ISLAND = 1;
    private static final int VISITED_BY_ME = 2;

    public int width;
    public int height;

    private final int[][] map;

    public Map(int width, int height, ArrayList<String> stringMap) {
        this.width = width;
        this.height = height;

        this.map = new int[width][height];
        for(int i = 0; i < stringMap.size(); i++) {
            for(int j = 0; j < stringMap.get(i).length(); j++) {
                map[i][j] = stringMap.get(i).charAt(j) == 'x' ? ISLAND : EMPTY;
            }
        }
    }

    public Point getEmptyCell() {
        for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                if(map[i][j] != ISLAND) {
                    return new Point(j, i);
                }
            }
        }
        return new Point(1, 1);
    }

    public boolean isSafeToMove(Point point) {
        if (point.getX() < 0 || point.getX() >= width || point.getY() < 0 || point.getY() >= height) {
            return false;
        }
        return map[point.getY()][point.getX()] == EMPTY;
    }

    public void setVisitedCell(Point point) {
        map[point.getY()][point.getX()] = VISITED_BY_ME;
    }

    public void resetVisitedCells() {
        for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                map[i][j] = map[i][j] == VISITED_BY_ME ? EMPTY : map[i][j];
            }
        }
    }
}

class Point {
    public int x;
    public int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }
}

class Submarine {
    private Point position;
    private int life;
    private int torpedoCooldown;
    private int sonarCooldown;
    private int silenceCooldown;
    private int mineCooldown;
    private Map map;

    public void update(Point position, int life, int torpedoCooldown, int sonarCooldown, int silenceCooldown, int mineCooldown) {
        this.position = position;
        this.life = life;
        this.torpedoCooldown = torpedoCooldown;
        this.sonarCooldown = sonarCooldown;
        this.silenceCooldown = silenceCooldown;
        this.mineCooldown = mineCooldown;

        map.setVisitedCell(position);
    }

    public void setMap(Map map) {
        this.map = map;
    }

    public void play() {
        move();
    }

    private void move() {
        Point north = new Point(position.getX(), position.getY() - 1);
        Point south = new Point(position.getX(), position.getY() + 1);
        Point east = new Point(position.getX() + 1, position.getY());
        Point west = new Point(position.getX() - 1, position.getY());

        if (map.isSafeToMove(north)) {
            moveTo("N");
        } else if (map.isSafeToMove(south)) {
            moveTo("S");
        } else if (map.isSafeToMove(east)) {
            moveTo("E");
        } else if (map.isSafeToMove(west)) {
            moveTo("W");
        } else {
            surface();
        }
    }

    private void moveTo(String direction) {
        System.out.println("MOVE " + direction + " TORPEDO | TORPEDO 1 1");
    }

    private void surface() {
        System.out.println("SURFACE");
        map.resetVisitedCells();
    }
}

/**
 * Auto-generated code below aims at helping you parse
 * the standard input according to the problem statement.
 **/
class Player {

    Map map;
    Submarine me = new Submarine();
    Submarine ennemy = new Submarine();

    public static void main(String[] args) {
        new Player().run();
    }

    private void run() {
        Scanner in = new Scanner(System.in);
        int width = in.nextInt();
        int height = in.nextInt();
        int myId = in.nextInt();
        if (in.hasNextLine()) {
            in.nextLine();
        }

        ArrayList<String> mapLines = new ArrayList<>();
        for (int i = 0; i < height; i++) {
            mapLines.add(in.nextLine());
        }

        map = new Map(width, height, mapLines);
        me.setMap(map);
        ennemy.setMap(map);

        // Write an action using System.out.println()
        // To debug: System.err.println("Debug messages...")

        Point initialPosition = map.getEmptyCell();


        System.out.println(initialPosition.getX() + " " + initialPosition.getY());

        // game loop
        while (true) {
            int x = in.nextInt();
            int y = in.nextInt();
            int myLife = in.nextInt();
            int oppLife = in.nextInt();
            int torpedoCooldown = in.nextInt();
            int sonarCooldown = in.nextInt();
            int silenceCooldown = in.nextInt();
            int mineCooldown = in.nextInt();
            String sonarResult = in.next();
            if (in.hasNextLine()) {
                in.nextLine();
            }
            String opponentOrders = in.nextLine();

            me.update(
                    new Point(x, y), myLife, torpedoCooldown, sonarCooldown, silenceCooldown, mineCooldown
            );
            // Write an action using System.out.println()
            // To debug: System.err.println("Debug messages...");

            me.play();
        }
    }
}