const readline = () => '...xx..x...';

// Coordinates definition
class Coordinates {
    x: number;
    y: number;

    constructor(x?: number, y?: number) {
        this.x = typeof x === 'number' ? x : -1;
        this.y = typeof y === 'number' ? y : -1;
    }

    public isAValidPositionInGrid(grid: CoordAndValue[]): boolean {
        return (
            this.x >= 0 &&
            this.x <= 14 &&
            this.y >= 0 &&
            this.y <= 14 &&
            findCoordInGridWithValue(grid, this)?.value === '.'
        );
    }

    public toString(): string {
        return '(' + this.x + ', ' + this.y + ')';
    }

    public equals(other: Coordinates): boolean {
        return this.x === other.x && this.y === other.y;
    }

    public sidePosition(direction: Directions) {
        let sidePosition: Coordinates = new Coordinates(this.x, this.y);
        switch (direction) {
            case Directions.NORTH:
                sidePosition.y -= 1;
                break;
            case Directions.SOUTH:
                sidePosition.y += 1;
                break;
            case Directions.EAST:
                sidePosition.x += 1;
                break;
            case Directions.WEST:
                sidePosition.x -= 1;
                break;
        }
        return sidePosition;
    }

    public isSidePositionAvailableForMeAtDirection(direction: Directions): boolean {
        return this.sidePosition(direction).isAValidPositionInGrid(myGrid);
    }
}

enum Directions {
    NORTH = 'N',
    SOUTH = 'S',
    EAST = 'E',
    WEST = 'W',
}

interface CoordAndValue {
    coord: Coordinates;
    value: string;
}

interface DirectionPriority {
    direction: Directions;
    priority: number;
}

const findCoordInGridWithValue = (grid: CoordAndValue[], coord: Coordinates) => {
    return grid.find((coordAndValue) => {
        return coordAndValue?.coord?.equals(coord);
    });
};

// Global initialization
var inputs: string[] = readline().split(' ');
const width: number = parseInt(inputs[0]);
const height: number = parseInt(inputs[1]);
const myId: number = parseInt(inputs[2]);
let myGrid: CoordAndValue[] = [];
let opponentGrid: CoordAndValue[] = [];
let possibleOpponentPositions: Coordinates[] = [];
let finalPossiblePathPosition: Coordinates = new Coordinates();
let opponentPosition: Coordinates = new Coordinates();

// Grids initialization
for (let lineIndex = 0; lineIndex < height; lineIndex++) {
    const lineValues: string[] = readline().split('');
    lineValues.forEach((value, indexInLine) => {
        let coord: Coordinates = new Coordinates(indexInLine, lineIndex);
        myGrid.push({ coord, value });
        opponentGrid.push({ coord, value });
        // if (value === '.') possibleOpponentStartingPositions.push(coord);
        if (value === '.') possibleOpponentPositions.push(coord);
    });
}

// Set my starting position
console.log('0 0');

///////////////// UTILS /////////////////

const printGrid = (grid: CoordAndValue[]): void => {
    for (let y = 0; y < height; y++) {
        let line: string = '';
        for (let x = 0; x < width; x++) {
            line = line.concat(grid[y * 15 + x].value);
        }
        console.error(line);
    }
};
const isActualOpponentPositionFound = (): boolean => {
    return opponentPosition.isAValidPositionInGrid(opponentGrid);
};

const markPositionAsUnavailable = (position: Coordinates) => {
    myGrid[myGrid.indexOf(findCoordInGridWithValue(myGrid, position)!)] = {
        coord: position,
        value: '!',
    };
};

const resetPath = () => {
    myGrid = myGrid.map((coordAndValue) => {
        coordAndValue.value = coordAndValue.value === '!' ? '.' : coordAndValue.value;
        return coordAndValue;
    });
};

const updatePossibleOpponentPositions = (opponentMove: string): void => {
    possibleOpponentPositions = possibleOpponentPositions
        .map((position) => {
            // Can't modify directly position, it changes the value in the grid
            let nextPosition: Coordinates = new Coordinates();
            switch (opponentMove) {
                case Directions.NORTH:
                    nextPosition = new Coordinates(position.x, position.y - 1);
                    break;
                case Directions.SOUTH:
                    nextPosition = new Coordinates(position.x, position.y + 1);
                    break;
                case Directions.EAST:
                    nextPosition = new Coordinates(position.x + 1, position.y);
                    break;
                case Directions.WEST:
                    nextPosition = new Coordinates(position.x - 1, position.y);
                    break;
            }
            return nextPosition;
        })
        .filter((position) => position.isAValidPositionInGrid(opponentGrid));
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// GAME LOOP ////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

let opponentLastMove: string = '';
while (true) {
    var inputs: string[] = readline().split(' ');
    const x: number = parseInt(inputs[0]);
    const y: number = parseInt(inputs[1]);
    const myPosition: Coordinates = new Coordinates(x, y);
    const myLife: number = parseInt(inputs[2]);
    const oppLife: number = parseInt(inputs[3]);
    const torpedoCooldown: number = parseInt(inputs[4]);
    const sonarCooldown: number = parseInt(inputs[5]);
    const silenceCooldown: number = parseInt(inputs[6]);
    const mineCooldown: number = parseInt(inputs[7]);
    const sonarResult: string = readline();

    //////////// Opponent orders ////////////
    const opponentOrders: string = readline();
    let opponentMove: string = '';
    if (opponentOrders.includes('MOVE')) {
        opponentMove = opponentOrders.substring(
            opponentOrders.indexOf('MOVE') + 5,
            opponentOrders.indexOf('MOVE') + 6
        );
    }
    if (opponentMove) updatePossibleOpponentPositions(opponentMove);

    let opponentSurfaceSector: number = 0;
    if (opponentOrders.includes('SURFACE')) {
        opponentSurfaceSector = parseInt(
            opponentOrders.substring(
                opponentOrders.indexOf('SURFACE') + 8,
                opponentOrders.indexOf('SURFACE') + 9
            )
        );
    }
    if (opponentSurfaceSector) {
        console.error('////////SURFACE////////');
        let xminSector = ((opponentSurfaceSector - 1) % 3) * 5;
        let xmaxSector = xminSector + 4;
        let yminSector = Math.trunc((opponentSurfaceSector - 1) / 3) * 5;
        let ymaxSector = yminSector + 4;

        console.error('possibleOpponentPositions.length: ' + possibleOpponentPositions.length);

        possibleOpponentPositions = possibleOpponentPositions.filter((position) => {
            return (
                position.x >= xminSector &&
                position.x <= xmaxSector &&
                position.y >= yminSector &&
                position.y <= ymaxSector
            );
        });
        console.error('after surface filter: ' + possibleOpponentPositions.length);
    }

    const opponentUsedSilence: boolean = opponentOrders.includes('SILENCE');
    if (opponentUsedSilence) {
        console.error('////////SILENCE////////');
        console.error('possibleOpponentPositions.length: ' + possibleOpponentPositions.length);

        // Pour chaque posiiton possible, on va regarder les 4 positions autour d'une case, puis de 2, de 3 et de 4
        // Si une position est possible (pas une ile ou en dehors la map) et pas déjà dans la liste des positions possibles on l'ajoute
        possibleOpponentPositions.forEach((position) => {
            let northPosition: Coordinates;
            let previousNorthPosition: boolean = true;
            let southPosition: Coordinates;
            let previousSouthPosition: boolean = true;
            let eastPosition: Coordinates;
            let previousEastPosition: boolean = true;
            let westPosition: Coordinates;
            let previousWestPosition: boolean = true;

            for (let i = 1; i <= 4; i++) {
                if (opponentLastMove !== Directions.NORTH && previousNorthPosition) {
                    northPosition = new Coordinates(position.x, position.y - i);
                    if (
                        northPosition.isAValidPositionInGrid(opponentGrid) &&
                        !possibleOpponentPositions.find((coord) => coord.equals(northPosition))
                    ) {
                        possibleOpponentPositions.push(northPosition);
                    } else {
                        previousNorthPosition = false;
                    }
                }

                if (opponentLastMove !== Directions.SOUTH && previousSouthPosition) {
                    southPosition = new Coordinates(position.x, position.y + i);
                    if (
                        southPosition.isAValidPositionInGrid(opponentGrid) &&
                        !possibleOpponentPositions.find((coord) => coord.equals(southPosition))
                    ) {
                        possibleOpponentPositions.push(southPosition);
                    } else {
                        previousSouthPosition = false;
                    }
                }

                if (opponentLastMove !== Directions.EAST && previousEastPosition) {
                    eastPosition = new Coordinates(position.x + i, position.y);
                    if (
                        eastPosition.isAValidPositionInGrid(opponentGrid) &&
                        !possibleOpponentPositions.find((coord) => coord.equals(eastPosition))
                    ) {
                        possibleOpponentPositions.push(eastPosition);
                    } else {
                        previousEastPosition = false;
                    }
                }

                if (opponentLastMove !== Directions.WEST && previousWestPosition) {
                    westPosition = new Coordinates(position.x - i, position.y);
                    if (
                        westPosition.isAValidPositionInGrid(opponentGrid) &&
                        !possibleOpponentPositions.find((coord) => coord.equals(westPosition))
                    ) {
                        possibleOpponentPositions.push(westPosition);
                    } else {
                        previousWestPosition = false;
                    }
                }
            }
        });
        console.error('after silence filter: ' + possibleOpponentPositions.length);
    }

    if (possibleOpponentPositions.length === 1) {
        opponentPosition = possibleOpponentPositions[0];
    }

    markPositionAsUnavailable(myPosition);

    opponentLastMove = opponentMove;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////// ACTIONS ////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////

    // --> Peut etre utiliser une liste d'actions qu'on concatène à la fin dans le console log.
    //        Ca permettrait d'ajouter des actions spécifiques selon le besoin.
    let action: string = '';

    if (!isActualOpponentPositionFound()) {
        // Opponent is not yet found, "random" moves
        for (let direction of Object.values(Directions)) {
            // Not possible in forEach because need to break from for loop
            if (!silenceCooldown) {
                let positionToCheck = new Coordinates(myPosition.x, myPosition.y);
                for (let distance = 1; distance <= 4; distance++) {
                    console.error('direction + distance');
                    console.error(direction + ' ' + distance);
                    if (!positionToCheck.isSidePositionAvailableForMeAtDirection(direction)) {
                        console.error('not available');
                        break;
                    }
                    action = 'SILENCE ' + direction + ' ' + distance;
                    console.error('action: ' + action);
                    markPositionAsUnavailable(positionToCheck)
                    positionToCheck = positionToCheck.sidePosition(direction);
                    printGrid(myGrid)
                }
            } else {
                if (myPosition.isSidePositionAvailableForMeAtDirection(direction)) {
                    action = 'MOVE ' + direction + ' SILENCE';
                }
            }
            if (action) break;
        }

        if (!action) {
            resetPath();
            action = 'SURFACE';
        }
        console.log(action);
    } else {
        // Opponent is found, LET'S KILL THIS MOTH******ER!!!
        console.error('//////FOUND//////');
        console.error(opponentPosition.toString());
        const distanceToOpponentLookingWest: number = myPosition.x - opponentPosition.x;
        const distanceToOpponentLookingNorth: number = myPosition.y - opponentPosition.y;
        const horizontalDistance: number = Math.abs(distanceToOpponentLookingWest);
        const verticalDistance: number = Math.abs(distanceToOpponentLookingNorth);

        if (horizontalDistance + verticalDistance <= 4 && !torpedoCooldown) {
            console.error('WE CAN SHOOT IT!!!');
            action = 'TORPEDO ' + opponentPosition.x + ' ' + opponentPosition.y;
        } else {
            console.error('TOO FAR TO SHOOT OR NO TORPEDOES');
            let directionPriorities: DirectionPriority[] = [];
            for (const direction of Object.values(Directions)) {
                directionPriorities.push({ direction, priority: 1 });
            }

            // Determine with direction to go towards the opponent and substitutes if unavailable
            directionPriorities = directionPriorities
                .map((directionPriority) => {
                    switch (directionPriority.direction) {
                        case Directions.NORTH:
                            if (verticalDistance > horizontalDistance) directionPriority.priority *= 2;
                            if (distanceToOpponentLookingNorth < 0) directionPriority.priority *= -1;
                            break;
                        case Directions.SOUTH:
                            if (verticalDistance > horizontalDistance) directionPriority.priority *= 2;
                            if (distanceToOpponentLookingNorth > 0) directionPriority.priority *= -1;
                            break;
                        case Directions.EAST:
                            if (horizontalDistance > verticalDistance) directionPriority.priority *= 2;
                            if (distanceToOpponentLookingWest > 0) directionPriority.priority *= -1;

                            break;
                        case Directions.WEST:
                            if (horizontalDistance > verticalDistance) directionPriority.priority *= 2;
                            if (distanceToOpponentLookingWest < 0) directionPriority.priority *= -1;
                            break;
                    }
                    return directionPriority;
                })
                .sort((a, b) => b.priority - a.priority);

            //// ACTION ////
            for (let direction of directionPriorities.map((dP) => dP.direction)) {
                // Not possible in forEach because need to break from for loop
                if (myPosition.isSidePositionAvailableForMeAtDirection(direction)) {
                    action = 'MOVE ' + direction + ' TORPEDO';
                }

                if (action) {
                    break;
                }
            }
            if (!action) {
                resetPath();
                action = 'SURFACE';
            }
        }
        console.log(action);
    }
}